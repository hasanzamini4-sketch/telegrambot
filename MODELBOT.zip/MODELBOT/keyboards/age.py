from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

def age_keyboard():
    rows, row = [], []
    for i in range(16, 61):
        row.append(KeyboardButton(text=str(i)))
        if len(row) == 4:
            rows.append(row)
            row = []
    if row:
        rows.append(row)
    return ReplyKeyboardMarkup(keyboard=rows, resize_keyboard=True)
