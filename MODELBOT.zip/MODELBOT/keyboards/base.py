from aiogram.types import ReplyKeyboardMarkup, KeyboardButton


def build_keyboard(keyboard: list):
    """
    تمام ReplyKeyboard ها باید از این تابع ساخته شوند
    دکمه بازگشت به منوی اصلی خودکار اضافه می‌شود
    """

    # بررسی اینکه قبلاً اضافه نشده باشد
    exists = any(
        button.text == "🔙 بازگشت به منوی اصلی"
        for row in keyboard
        for button in row
    )

    if not exists:
        keyboard.append(
            [KeyboardButton(text="🔙 بازگشت به منوی اصلی")]
        )

    return ReplyKeyboardMarkup(
        keyboard=keyboard,
        resize_keyboard=True
    )
