import json
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

def province_keyboard():
    with open("data/provinces.json", "r", encoding="utf-8") as f:
        provinces = json.load(f)

    buttons = []
    row = []
    for name in provinces.keys():
        row.append(KeyboardButton(text=name))
        if len(row) == 2:
            buttons.append(row)
            row = []
    if row:
        buttons.append(row)

    return ReplyKeyboardMarkup(
        keyboard=buttons,
        resize_keyboard=True
    )
