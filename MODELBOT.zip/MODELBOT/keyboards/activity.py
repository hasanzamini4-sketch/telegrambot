from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

def activity_keyboard():
    activities = [
        "فشن",
        "بیوتی",
        "میکاپ",
        "مانتو",
        "تبلیغاتی",
        "عکاسی",
        "ویدئویی"
    ]

    buttons = []
    row = []
    for act in activities:
        row.append(KeyboardButton(text=act))
        if len(row) == 2:
            buttons.append(row)
            row = []
    if row:
        buttons.append(row)

    return ReplyKeyboardMarkup(
        keyboard=buttons,
        resize_keyboard=True
    )
