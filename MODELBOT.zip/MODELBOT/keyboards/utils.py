from aiogram.types import KeyboardButton


def add_back_button(keyboard: list):
    keyboard.append([KeyboardButton(text="🔙 بازگشت به منوی اصلی")])
    return keyboard
