from aiogram.types import ReplyKeyboardMarkup, KeyboardButton


def model_main_menu():
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="📄 پروفایل من")],
            [KeyboardButton(text="📂 پروژه‌های فعال")],
            [KeyboardButton(text="💬 درخواست‌های همکاری")],
        ],
        resize_keyboard=True
    )
