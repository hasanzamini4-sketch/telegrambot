from aiogram.types import ReplyKeyboardMarkup, KeyboardButton


def employer_main_menu():
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="➕ ثبت پروژه")],
            [KeyboardButton(text="📋 پروژه‌های من")],
            [KeyboardButton(text="🔍 مشاهده مدل‌ها")],
        ],
        resize_keyboard=True
    )
