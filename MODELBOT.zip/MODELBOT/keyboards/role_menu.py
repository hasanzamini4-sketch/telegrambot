from aiogram.types import KeyboardButton
from keyboards.base import build_keyboard


def model_menu():
    keyboard = [
        [KeyboardButton(text="👤 پروفایل من")],
        [KeyboardButton(text="🔍 جستجوی پروژه")],
    ]

    return build_keyboard(keyboard)


def employer_menu():
    keyboard = [
        [KeyboardButton(text="📂 پروژه‌های من")],
        [KeyboardButton(text="🔍 جستجوی مدل")],
    ]

    return build_keyboard(keyboard)
