from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

def days_keyboard():
    days = [
        "شنبه", "یکشنبه",
        "دوشنبه", "سه‌شنبه",
        "چهارشنبه", "پنجشنبه",
        "جمعه",
        "✅ ثبت نهایی"
    ]

    keyboard = []
    row = []
    for day in days:
        row.append(KeyboardButton(text=day))
        if len(row) == 2:
            keyboard.append(row)
            row = []
    if row:
        keyboard.append(row)

    return ReplyKeyboardMarkup(
        keyboard=keyboard,
        resize_keyboard=True
    )
