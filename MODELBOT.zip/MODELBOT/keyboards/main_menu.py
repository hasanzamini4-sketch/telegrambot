from aiogram.types import KeyboardButton
from keyboards.base import build_keyboard


def main_menu():
    keyboard = [
        [KeyboardButton(text="📝 ثبت نام مدل"), KeyboardButton(text="📝 ثبت نام کارفرما")],
        [KeyboardButton(text="🔍 جستجوی مدل"), KeyboardButton(text="🔍 مشاهده مدل‌ها")],
        [KeyboardButton(text="📂 پروژه‌های من")],
        [KeyboardButton(text="➕ ثبت پروژه کاری")],
        [KeyboardButton(text="👤 پروفایل من")]
    ]

    return build_keyboard(keyboard)
