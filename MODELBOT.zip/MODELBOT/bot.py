import asyncio
from aiogram import Bot, Dispatcher
from aiogram.fsm.storage.memory import MemoryStorage

from config import TOKEN
from database.db import init_db

from handlers import common, start, register_model, register_employer
from handlers.model import router as model_router
from handlers.employer import router as employer_router


async def main():
    init_db()

    bot = Bot(token=TOKEN)
    dp = Dispatcher(storage=MemoryStorage())

    # عمومی
    dp.include_router(common.router)
    dp.include_router(start.router)
    dp.include_router(register_model.router)
    dp.include_router(register_employer.router)

    # نقش‌ها
    dp.include_router(model_router)
    dp.include_router(employer_router)

    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
