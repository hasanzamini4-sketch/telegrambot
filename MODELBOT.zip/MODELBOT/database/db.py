import os
import sqlite3

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_NAME = os.path.join(BASE_DIR, "..", "database.db")
DB_NAME = os.path.abspath(DB_NAME)


def get_connection():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_connection()
    cur = conn.cursor()

    # USERS
    cur.execute("""
    CREATE TABLE IF NOT EXISTS users (
        telegram_id INTEGER PRIMARY KEY,
        role TEXT,
        name TEXT
    )
    """)

    # MODELS
    cur.execute("""
    CREATE TABLE IF NOT EXISTS models (
        telegram_id INTEGER PRIMARY KEY,
        name TEXT,
        age INTEGER,
        height INTEGER,
        weight INTEGER,
        city TEXT,
        activity TEXT,
        hours TEXT,
        price INTEGER,
        instagram TEXT,
        photo TEXT,
        approved INTEGER DEFAULT 0
    )
    """)

    # EMPLOYERS
    cur.execute("""
    CREATE TABLE IF NOT EXISTS employers (
        telegram_id INTEGER PRIMARY KEY,
        name TEXT,
        city TEXT,
        phone TEXT,
        description TEXT,
        instagram TEXT,
        photo TEXT,
        approved INTEGER DEFAULT 0
    )
    """)

    # PROJECTS
    cur.execute("""
    CREATE TABLE IF NOT EXISTS projects (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        employer_id INTEGER,
        title TEXT,
        description TEXT,
        province TEXT,
        city TEXT,
        date TEXT,
        time TEXT,
        style TEXT,
        price TEXT,
        status TEXT DEFAULT 'draft'
    )
    """)

    conn.commit()
    conn.close()


# ================= USERS =================

def set_user_role(telegram_id, role, name=None):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO users (telegram_id, role, name)
        VALUES (?, ?, ?)
        ON CONFLICT(telegram_id) DO UPDATE SET role=excluded.role
    """, (telegram_id, role, name))
    conn.commit()
    conn.close()


def get_user_role(telegram_id):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT role FROM users WHERE telegram_id = ?", (telegram_id,))
    row = cur.fetchone()
    conn.close()
    return row["role"] if row else None


# ================= MODELS =================

def create_model(data):
    conn = get_connection()
    cur = conn.cursor()

    cur.execute("""
        INSERT OR REPLACE INTO models (
            telegram_id, name, age, height, weight,
            city, activity, hours, price,
            instagram, photo, approved
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)
    """, (
        data["telegram_id"],
        data["name"],
        data["age"],
        data["height"],
        data["weight"],
        data["city"],
        data["activity"],
        data["hours"],
        data["price"],
        data.get("instagram"),
        data.get("photo"),
    ))

    conn.commit()
    conn.close()


def get_model(telegram_id):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM models WHERE telegram_id = ?", (telegram_id,))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None


def get_model_by_id(telegram_id):
    return get_model(telegram_id)


def approve_model(telegram_id):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("UPDATE models SET approved = 1 WHERE telegram_id = ?", (telegram_id,))
    conn.commit()
    conn.close()


def get_all_approved_models():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM models WHERE approved = 1")
    rows = cur.fetchall()
    conn.close()
    return [dict(row) for row in rows]


def search_models(filters: dict):
    conn = get_connection()
    cursor = conn.cursor()

    query = "SELECT * FROM models WHERE approved = 1"
    params = []

    if filters.get("city"):
        query += " AND city = ?"
        params.append(filters["city"])

    if filters.get("activity"):
        query += " AND activity LIKE ?"
        params.append(f"%{filters['activity']}%")

    if filters.get("max_price") is not None:
        query += " AND price <= ?"
        params.append(filters["max_price"])

    if filters.get("min_age") is not None:
        query += " AND age >= ?"
        params.append(filters["min_age"])

    if filters.get("max_age") is not None:
        query += " AND age <= ?"
        params.append(filters["max_age"])

    cursor.execute(query, params)
    rows = cursor.fetchall()
    conn.close()

    return [dict(row) for row in rows]


# ================= EMPLOYERS =================

def create_employer(data):
    conn = get_connection()
    cur = conn.cursor()

    cur.execute("""
        INSERT OR REPLACE INTO employers (
            telegram_id, name, city, phone,
            description, instagram, photo, approved
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, 0)
    """, (
        data["telegram_id"],
        data["name"],
        data["city"],
        data["phone"],
        data["description"],
        data.get("instagram"),
        data.get("photo"),
    ))

    conn.commit()
    conn.close()


def get_employer(telegram_id):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM employers WHERE telegram_id = ?", (telegram_id,))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None


def approve_employer(telegram_id):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("UPDATE employers SET approved = 1 WHERE telegram_id = ?", (telegram_id,))
    conn.commit()
    conn.close()


# ================= PROJECTS =================

def create_project(data):
    conn = get_connection()
    cur = conn.cursor()

    cur.execute("""
        INSERT INTO projects (
            employer_id, title, description,
            province, city, date, time,
            style, price, status
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')
    """, (
        data["employer_id"],
        data["title"],
        data["description"],
        data["province"],
        data["city"],
        data["date"],
        data["time"],
        data["style"],
        data["price"],
    ))

    conn.commit()
    conn.close()


def get_projects_by_employer(employer_id):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM projects WHERE employer_id = ?", (employer_id,))
    rows = cur.fetchall()
    conn.close()
    return [dict(row) for row in rows]


def get_project_by_id(project_id):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM projects WHERE id = ?", (project_id,))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None


def get_active_projects():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM projects WHERE status = 'active'")
    rows = cur.fetchall()
    conn.close()
    return [dict(row) for row in rows]


def delete_project(project_id):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM projects WHERE id = ?", (project_id,))
    conn.commit()
    conn.close()


# ✅ اضافه شده برای رفع خطای جدید
def update_project_field(project_id, field_name, value):
    allowed_fields = [
        "title",
        "description",
        "province",
        "city",
        "date",
        "time",
        "style",
        "price",
        "status"
    ]

    if field_name not in allowed_fields:
        return False

    conn = get_connection()
    cur = conn.cursor()

    query = f"UPDATE projects SET {field_name} = ? WHERE id = ?"
    cur.execute(query, (value, project_id))

    conn.commit()
    conn.close()
    return True
