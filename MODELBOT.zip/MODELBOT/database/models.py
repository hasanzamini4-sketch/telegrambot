from database.db import get_db

def init_db():
    db = get_db()
    cursor = db.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            role TEXT,
            name TEXT,
            age INTEGER,
            province TEXT,
            city TEXT,
            step TEXT,
            is_verified INTEGER DEFAULT 0
        )
    """)
    db.commit()
    db.close()
