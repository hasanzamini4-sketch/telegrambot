from aiogram import Router
from aiogram.types import Message
from aiogram.filters import CommandStart

from database.db import get_user_role
from keyboards.model_menu import model_main_menu
from keyboards.employer_menu import employer_main_menu

router = Router()


@router.message(CommandStart())
async def start_handler(message: Message):

    role = get_user_role(message.from_user.id)

    if role == "model":
        await message.answer(
            "به پنل مدل خوش آمدید 👗",
            reply_markup=model_main_menu()
        )

    elif role == "employer":
        await message.answer(
            "به پنل کارفرما خوش آمدید 🏢",
            reply_markup=employer_main_menu()
        )

    else:
        await message.answer("لطفا ثبت نام کنید.")
