import json
import os
from aiogram import Router, types, F
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext

router = Router()

CHAT_PATH = "data/chats.json"
MODELS_PATH = "data/models.json"
EMPLOYERS_PATH = "data/employers.json"


# ================= ابزار =================

def load(path):
    os.makedirs("data", exist_ok=True)

    if not os.path.exists(path):
        with open(path, "w", encoding="utf-8") as f:
            json.dump({}, f)

    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def get_profile_name(user_id: str):
    models = load(MODELS_PATH)
    employers = load(EMPLOYERS_PATH)

    if user_id in models:
        return f"مدل | {models[user_id].get('name', 'بدون نام')}"

    if user_id in employers:
        return f"کارفرما | {employers[user_id].get('name', 'بدون نام')}"

    return "کاربر"


# ================= چت =================
# فقط پیام‌های معمولی — نه دستور، نه وقتی FSM فعاله

@router.message(F.text & ~F.text.startswith("/"))
async def relay_chat(message: types.Message, state: FSMContext):

    # اگر داخل یک State باشیم (ثبت پروژه، ویرایش و...)
    # چت نباید فعال شود
    if await state.get_state() is not None:
        return

    chats = load(CHAT_PATH)
    user_id = str(message.from_user.id)

    # اگر این کاربر در حال چت با کسی نیست
    if user_id not in chats:
        return

    target_id = chats[user_id]
    sender_name = get_profile_name(user_id)

    await message.bot.send_message(
        int(target_id),
        f"💬 {sender_name}:\n{message.text}"
    )
