from aiogram import Router

# ساخت router اصلی مدل
router = Router(name="model_router")

# import مستقیم ماژول‌ها (ایمن‌تر از import گروهی)
from handlers.profile import router as profile_router
from handlers.edit_profile import router as edit_profile_router
from handlers.offers import router as offers_router
from handlers.chat import router as chat_router

# include کردن زیرروترها
router.include_router(profile_router)
router.include_router(edit_profile_router)
router.include_router(offers_router)
router.include_router(chat_router)
