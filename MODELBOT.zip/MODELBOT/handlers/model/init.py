from aiogram import Router
from middlewares.role_middleware import RoleMiddleware

router = Router()
router.message.middleware(RoleMiddleware("model"))

from . import menu
from . import profile
from . import projects
from . import chat
