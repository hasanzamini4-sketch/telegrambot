from aiogram import Router
from middlewares.role_middleware import RoleMiddleware

router = Router()
router.message.middleware(RoleMiddleware("employer"))

from . import menu
from . import projects
from . import browse_models
from . import chat
