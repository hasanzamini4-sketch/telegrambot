from aiogram import Router

# ساخت router اصلی کارفرما
router = Router(name="employer_router")

# import مستقیم ماژول‌ها
from handlers.projects import router as projects_router
from handlers.browse_models import router as browse_models_router
from handlers.search_models import router as search_models_router
from handlers.requests import router as requests_router

# include زیرروترها
router.include_router(projects_router)
router.include_router(browse_models_router)
router.include_router(search_models_router)
router.include_router(requests_router)
