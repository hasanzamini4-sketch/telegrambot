import json, os
from aiogram import Router, types, F
from aiogram.fsm.context import FSMContext
from aiogram.filters import StateFilter
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from states.edit_profile import EditProfile

router = Router()
MODELS_PATH = "data/models.json"


# ---------- ابزار ----------

def load_models():
    os.makedirs("data", exist_ok=True)
    if not os.path.exists(MODELS_PATH):
        with open(MODELS_PATH, "w", encoding="utf-8") as f:
            json.dump({}, f)
    with open(MODELS_PATH, encoding="utf-8") as f:
        return json.load(f)


def save_models(data):
    with open(MODELS_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def render_profile(m):
    return (
        f"👤 نام: {m['name']}\n"
        f"🎂 سن: {m['age']}\n"
        f"📏 قد: {m['height']} cm\n"
        f"⚖️ وزن: {m['weight']} kg\n"
        f"📍 استان: {m['province']}\n"
        f"🏙 شهر: {m['city']}\n"
        f"🎭 فعالیت: {m['activity']}\n"
        f"📆 روزها: {m['days']}\n"
        f"⏰ ساعات: {m['hours']}\n"
        f"💰 آفیش: {m['price']:,} تومان"
    )


def edit_menu():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🖼 عکس", callback_data="edit_photo")],
        [InlineKeyboardButton(text="👤 نام", callback_data="edit_name")],
        [InlineKeyboardButton(text="🎂 سن", callback_data="edit_age"),
         InlineKeyboardButton(text="📏 قد", callback_data="edit_height")],
        [InlineKeyboardButton(text="⚖️ وزن", callback_data="edit_weight")],
        [InlineKeyboardButton(text="📍 استان", callback_data="edit_province"),
         InlineKeyboardButton(text="🏙 شهر", callback_data="edit_city")],
        [InlineKeyboardButton(text="🎭 فعالیت", callback_data="edit_activity")],
        [InlineKeyboardButton(text="📆 روزها", callback_data="edit_days"),
         InlineKeyboardButton(text="⏰ ساعات", callback_data="edit_hours")],
        [InlineKeyboardButton(text="💰 آفیش", callback_data="edit_price")],
        [InlineKeyboardButton(text="👁 مشاهده پروفایل", callback_data="my_profile")]
    ])


# ---------- منوی ویرایش ----------

@router.callback_query(F.data == "edit_profile")
async def open_edit(call: types.CallbackQuery, state: FSMContext):
    await state.clear()
    await call.message.answer("✏️ بخش مورد نظر را انتخاب کن:", reply_markup=edit_menu())
    await call.answer()


# ---------- عکس ----------

@router.callback_query(F.data == "edit_photo")
async def ask_photo(call, state):
    await state.set_state(EditProfile.photo)
    await call.message.answer("🖼 عکس جدید را ارسال کن:")
    await call.answer()


@router.message(StateFilter(EditProfile.photo), F.photo)
async def save_photo(message, state):
    uid = str(message.from_user.id)
    models = load_models()
    models[uid]["photo"] = message.photo[-1].file_id
    save_models(models)
    await state.clear()
    await message.answer("✅ عکس ذخیره شد", reply_markup=edit_menu())


# ---------- فیلدهای متنی ----------

FIELD_MAP = {
    EditProfile.name: "name",
    EditProfile.age: "age",
    EditProfile.height: "height",
    EditProfile.weight: "weight",
    EditProfile.province: "province",
    EditProfile.city: "city",
    EditProfile.activity: "activity",
    EditProfile.days: "days",
    EditProfile.hours: "hours",
    EditProfile.price: "price",
}


@router.callback_query(F.data.startswith("edit_"))
async def ask_field(call, state):
    mapping = {
        "edit_name": (EditProfile.name, "👤 نام جدید:"),
        "edit_age": (EditProfile.age, "🎂 سن جدید:"),
        "edit_height": (EditProfile.height, "📏 قد (cm):"),
        "edit_weight": (EditProfile.weight, "⚖️ وزن (kg):"),
        "edit_province": (EditProfile.province, "📍 استان:"),
        "edit_city": (EditProfile.city, "🏙 شهر:"),
        "edit_activity": (EditProfile.activity, "🎭 فعالیت:"),
        "edit_days": (EditProfile.days, "📆 روزها:"),
        "edit_hours": (EditProfile.hours, "⏰ ساعات:"),
        "edit_price": (EditProfile.price, "💰 آفیش:"),
    }

    if call.data not in mapping:
        return

    state_name, text = mapping[call.data]
    await state.set_state(state_name)
    await call.message.answer(text)
    await call.answer()


@router.message(StateFilter(*FIELD_MAP.keys()))
async def save_field(message, state):
    uid = str(message.from_user.id)
    models = load_models()

    current_state = await state.get_state()
    field = FIELD_MAP[getattr(EditProfile, current_state.split(":")[1])]

    value = message.text
    if field in ["age", "height", "weight", "price"]:
        if not value.isdigit():
            return await message.answer("❌ فقط عدد")
        value = int(value)

    models[uid][field] = value
    save_models(models)

    await state.clear()
    await message.answer("✅ ذخیره شد", reply_markup=edit_menu())
