from database.db import set_user_role
from keyboards.role_menu import employer_menu
from aiogram import Router, types, F
from aiogram.fsm.context import FSMContext
from aiogram.filters import StateFilter
from aiogram.types import (
    ReplyKeyboardMarkup, KeyboardButton,
    ReplyKeyboardRemove, InlineKeyboardMarkup, InlineKeyboardButton
)

from states.register import RegisterEmployer
from config import ADMIN_ID
from database.db import create_employer, approve_employer, get_employer

router = Router()


# ================= منوی اصلی =================

def main_menu():
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="📝 ثبت نام مدل"), KeyboardButton(text="📝 ثبت نام کارفرما")],
            [KeyboardButton(text="🔎 جستجوی مدل"), KeyboardButton(text="🔎 جستجوی کارفرما")],
            [KeyboardButton(text="📂 مشاهده پروژه‌ها")],
            [KeyboardButton(text="👤 پروفایل من"), KeyboardButton(text="🏠 منوی اصلی")]
        ],
        resize_keyboard=True
    )


# ================= شروع ثبت نام =================

@router.message(F.text.contains("ثبت نام کارفرما"))
async def start_employer_register(message: types.Message, state: FSMContext):
    existing = get_employer(message.from_user.id)
    if existing:
        return await message.answer(
            "✅ قبلاً ثبت‌نام کرده‌ای",
            reply_markup=main_menu()
        )

    await state.clear()
    await state.set_state(RegisterEmployer.name)

    await message.answer(
        "🏢 نام شرکت یا مجموعه:",
        reply_markup=ReplyKeyboardRemove()
    )


# ================= مراحل فرم =================

@router.message(StateFilter(RegisterEmployer.name))
async def process_name(message: types.Message, state: FSMContext):
    await state.update_data(name=message.text.strip())
    await state.set_state(RegisterEmployer.city)
    await message.answer("📍 شهر:")


@router.message(StateFilter(RegisterEmployer.city))
async def process_city(message: types.Message, state: FSMContext):
    await state.update_data(city=message.text.strip())
    await state.set_state(RegisterEmployer.phone)
    await message.answer("📞 شماره تماس:")


@router.message(StateFilter(RegisterEmployer.phone))
async def process_phone(message: types.Message, state: FSMContext):
    await state.update_data(phone=message.text.strip())
    await state.set_state(RegisterEmployer.description)
    await message.answer("📝 توضیحات کوتاه درباره فعالیت شما:")


@router.message(StateFilter(RegisterEmployer.description))
async def process_description(message: types.Message, state: FSMContext):
    await state.update_data(description=message.text.strip())
    await state.set_state(RegisterEmployer.instagram)
    await message.answer("📸 آیدی اینستاگرام (اختیاری - اگر نداری بنویس: ندارد)")


@router.message(StateFilter(RegisterEmployer.instagram))
async def process_instagram(message: types.Message, state: FSMContext):
    text = message.text.strip()
    if text.lower() == "ندارد":
        text = None

    await state.update_data(instagram=text)
    await state.set_state(RegisterEmployer.photo)
    await message.answer("🖼 لوگو یا عکس مجموعه را ارسال کن")


# ================= ذخیره در دیتابیس =================

@router.message(StateFilter(RegisterEmployer.photo), F.photo)
async def process_photo(message: types.Message, state: FSMContext):
    data = await state.get_data()

    employer_data = {
        "telegram_id": message.from_user.id,
        "name": data["name"],
        "city": data["city"],
        "phone": data["phone"],
        "description": data["description"],
        "instagram": data.get("instagram"),
        "photo": message.photo[-1].file_id
    }

    create_employer(employer_data)

    kb = InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(
            text="✅ تأیید",
            callback_data=f"employer_ok:{message.from_user.id}"
        )
    ]])

    await message.bot.send_photo(
        ADMIN_ID,
        message.photo[-1].file_id,
        caption=f"کارفرمای جدید:\n{data['name']}\nشهر: {data['city']}",
        reply_markup=kb
    )

    await message.answer("✅ برای بررسی ارسال شد")
    await state.clear()


@router.message(StateFilter(RegisterEmployer.photo))
async def photo_required(message: types.Message):
    await message.answer("❗ لطفاً فقط عکس ارسال کن")


# ================= تأیید ادمین =================

@router.callback_query(F.data.startswith("employer_ok:"))
async def approve_employer_handler(call: types.CallbackQuery):
    user_id = int(call.data.split(":")[1])

    approve_employer(user_id)
    set_user_role(user_id, "employer")

    await call.bot.send_message(
        user_id,
        "🎉 ثبت‌نام شما تأیید شد",
        reply_markup=employer_menu()
    )

    await call.answer()
    await call.message.edit_reply_markup()
