from aiogram import Router, types, F
from aiogram.fsm.context import FSMContext
from keyboards.main_menu import main_menu

router = Router()


@router.message(F.text == "🔙 بازگشت به منوی اصلی")
async def global_back(message: types.Message, state: FSMContext):
    await state.clear()

    await message.answer(
        "🏠 به منوی اصلی برگشتی",
        reply_markup=main_menu()
    )
