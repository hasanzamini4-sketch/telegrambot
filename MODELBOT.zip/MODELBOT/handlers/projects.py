from aiogram import Router, types, F
from aiogram.filters import StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import StatesGroup, State
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from database.db import (
    get_projects_by_employer,
    delete_project,
    update_project_field
)

router = Router()


# ================= STATES =================

class EditProject(StatesGroup):
    project_id = State()
    field = State()
    value = State()

class CreateProject(StatesGroup):
    title = State()
    description = State()
    province = State()
    city = State()
    date = State()
    time = State()
    style = State()
    price = State()

# ================= CONSTANT DATA =================

PROVINCES = {
    "تهران": ["تهران", "ری", "شمیرانات"],
    "البرز": ["کرج", "فردیس", "نظرآباد"],
}

TIMES = ["08:00","10:00","12:00","14:00","16:00","18:00","20:00"]
STYLES = ["فشن","بیوتی","مانتو","کت شلوار","مردانه","زنانه","بچگانه"]

MONTHS = [
    "فروردین","اردیبهشت","خرداد","تیر","مرداد","شهریور",
    "مهر","آبان","آذر","دی","بهمن","اسفند"
]


def days_in_month(month_index):
    if month_index <= 6:
        return range(1, 32)
    if month_index <= 11:
        return range(1, 31)
    return range(1, 30)

from database.db import create_project


@router.message(F.text == "➕ ثبت پروژه کاری")
async def start_project(message: types.Message, state: FSMContext):
    await state.clear()
    await state.set_state(CreateProject.title)
    await message.answer("📝 عنوان پروژه را وارد کن:")
# ================= ثبت پروژه مرحله‌ای =================

@router.message(StateFilter(CreateProject.title))
async def project_title(message: types.Message, state: FSMContext):
    await state.update_data(title=message.text)
    await state.set_state(CreateProject.description)
    await message.answer("📄 توضیحات پروژه را وارد کن:")


@router.message(StateFilter(CreateProject.description))
async def project_description(message: types.Message, state: FSMContext):
    await state.update_data(description=message.text)
    await state.set_state(CreateProject.province)

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text=p, callback_data=f"prov_{p}")]
            for p in PROVINCES
        ]
    )

    await message.answer("📍 استان را انتخاب کن:", reply_markup=kb)


@router.callback_query(StateFilter(CreateProject.province), F.data.startswith("prov_"))
async def select_province(call: types.CallbackQuery, state: FSMContext):
    province = call.data.replace("prov_", "")
    await state.update_data(province=province)
    await state.set_state(CreateProject.city)

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text=c, callback_data=f"city_{c}")]
            for c in PROVINCES[province]
        ]
    )

    await call.message.answer("🏙 شهر را انتخاب کن:", reply_markup=kb)
    await call.answer()


@router.callback_query(StateFilter(CreateProject.city), F.data.startswith("city_"))
async def select_city(call: types.CallbackQuery, state: FSMContext):
    city = call.data.replace("city_", "")
    await state.update_data(city=city)
    await state.set_state(CreateProject.date)

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text=m, callback_data=f"month_{i+1}")]
            for i, m in enumerate(MONTHS)
        ]
    )

    await call.message.answer("📅 ماه را انتخاب کن:", reply_markup=kb)
    await call.answer()


@router.callback_query(StateFilter(CreateProject.date), F.data.startswith("month_"))
async def select_day(call: types.CallbackQuery):
    m = int(call.data.replace("month_", ""))

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text=str(d), callback_data=f"day_{MONTHS[m-1]} {d}")]
            for d in days_in_month(m)
        ]
    )

    await call.message.answer("روز را انتخاب کن:", reply_markup=kb)
    await call.answer()


@router.callback_query(StateFilter(CreateProject.date), F.data.startswith("day_"))
async def save_date(call: types.CallbackQuery, state: FSMContext):
    date = call.data.replace("day_", "")
    await state.update_data(date=date)
    await state.set_state(CreateProject.time)

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text=t, callback_data=f"time_{t}")]
            for t in TIMES
        ]
    )

    await call.message.answer("⏰ ساعت را انتخاب کن:", reply_markup=kb)
    await call.answer()


@router.callback_query(StateFilter(CreateProject.time), F.data.startswith("time_"))
async def select_style(call: types.CallbackQuery, state: FSMContext):
    time = call.data.replace("time_", "")
    await state.update_data(time=time)
    await state.set_state(CreateProject.style)

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text=s, callback_data=f"style_{s}")]
            for s in STYLES
        ]
    )

    await call.message.answer("🎨 سبک پروژه را انتخاب کن:", reply_markup=kb)
    await call.answer()


@router.callback_query(StateFilter(CreateProject.style), F.data.startswith("style_"))
async def save_style(call: types.CallbackQuery, state: FSMContext):
    style = call.data.replace("style_", "")
    await state.update_data(style=style)
    await state.set_state(CreateProject.price)

    await call.message.answer("💰 آفیش را وارد کن:")
    await call.answer()


@router.message(StateFilter(CreateProject.price))
async def save_project(message: types.Message, state: FSMContext):
    data = await state.get_data()

    data["employer_id"] = message.from_user.id
    data["price"] = message.text

    create_project(data)

    await state.clear()
    await message.answer("✅ پروژه با موفقیت ثبت شد")

# ================= نمایش پروژه‌ها =================

@router.message(F.text == "📂 پروژه‌های من")
async def my_projects(message: types.Message):
    uid = message.from_user.id
    projects = get_projects_by_employer(uid)

    if not projects:
        return await message.answer("❌ پروژه‌ای ثبت نکرده‌ای")

    for p in projects:
        await message.answer(
            f"📌 {p.get('title','-')}\n"
            f"📝 {p.get('description','-')}\n"
            f"📍 {p.get('province','-')} / {p.get('city','-')}\n"
            f"📅 {p.get('date','-')}\n"
            f"⏰ {p.get('time','-')}\n"
            f"💰 {p.get('price','-')}\n"
            f"🎨 {p.get('style','-')}",
            reply_markup=InlineKeyboardMarkup(
                inline_keyboard=[[ 
                    InlineKeyboardButton(text="✏️ ویرایش", callback_data=f"edit_{p['id']}"),
                    InlineKeyboardButton(text="🗑 حذف", callback_data=f"del_{p['id']}")
                ]]
            )
        )


# ================= حذف =================

@router.callback_query(F.data.startswith("del_"))
async def delete_project_handler(call: types.CallbackQuery):
    pid = int(call.data.replace("del_", ""))
    delete_project(pid)

    await call.message.answer("🗑 پروژه حذف شد")
    await call.answer()


# ================= فیلدهای قابل ویرایش =================

EDIT_FIELDS = {
    "title": "عنوان",
    "description": "توضیحات",
    "province": "استان",
    "city": "شهر",
    "date": "تاریخ",
    "time": "ساعت",
    "price": "آفیش",
    "style": "سبک",
}


# ================= شروع ویرایش =================

@router.callback_query(F.data.startswith("edit_"))
async def start_edit(call: types.CallbackQuery, state: FSMContext):
    pid = int(call.data.replace("edit_", ""))
    await state.update_data(project_id=pid)
    await state.set_state(EditProject.field)

    await call.message.answer(
        "✏️ کدام بخش ویرایش شود؟",
        reply_markup=InlineKeyboardMarkup(
            inline_keyboard=[
                [InlineKeyboardButton(text=v, callback_data=f"field_{k}")]
                for k, v in EDIT_FIELDS.items()
            ]
        )
    )
    await call.answer()


# ================= انتخاب فیلد =================

@router.callback_query(StateFilter(EditProject.field), F.data.startswith("field_"))
async def choose_field(call: types.CallbackQuery, state: FSMContext):
    field = call.data.replace("field_", "")
    await state.update_data(field=field)

    kb = None

    if field == "province":
        kb = [[InlineKeyboardButton(text=p, callback_data=f"val_{p}")]
              for p in PROVINCES]

    elif field == "time":
        kb = [[InlineKeyboardButton(text=t, callback_data=f"val_{t}")]
              for t in TIMES]

    elif field == "style":
        kb = [[InlineKeyboardButton(text=s, callback_data=f"val_{s}")]
              for s in STYLES]

    elif field == "date":
        kb = [[InlineKeyboardButton(text=m, callback_data=f"month_{i+1}")]
              for i, m in enumerate(MONTHS)]

    await state.set_state(EditProject.value)

    if kb:
        await call.message.answer("انتخاب کن:", reply_markup=InlineKeyboardMarkup(inline_keyboard=kb))
    else:
        await call.message.answer("✍️ مقدار جدید را وارد کن:")

    await call.answer()


# ================= انتخاب روز =================

@router.callback_query(StateFilter(EditProject.value), F.data.startswith("month_"))
async def choose_day(call: types.CallbackQuery):
    m = int(call.data.replace("month_", ""))
    kb = [[InlineKeyboardButton(text=str(d), callback_data=f"val_{MONTHS[m-1]} {d}")]
          for d in days_in_month(m)]

    await call.message.answer("روز را انتخاب کن:",
                              reply_markup=InlineKeyboardMarkup(inline_keyboard=kb))
    await call.answer()


# ================= ذخیره مقدار =================

@router.callback_query(StateFilter(EditProject.value), F.data.startswith("val_"))
async def save_button_value(call: types.CallbackQuery, state: FSMContext):
    await save_value(call.message, state, call.data.replace("val_", ""))
    await call.answer()


@router.message(StateFilter(EditProject.value))
async def save_text_value(msg: types.Message, state: FSMContext):
    await save_value(msg, state, msg.text)


async def save_value(msg, state, value):
    data = await state.get_data()

    update_project_field(
        data["project_id"],
        data["field"],
        value
    )

    await state.clear()
    await msg.answer("✅ اطلاعات پروژه با موفقیت ویرایش شد")
