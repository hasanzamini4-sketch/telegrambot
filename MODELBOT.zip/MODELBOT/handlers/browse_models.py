from aiogram import Router, types, F
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from database.db import get_all_approved_models, get_model_by_id

router = Router()

# ================= لیست مدل‌ها =================

@router.message(F.text == "🔍 مشاهده مدل‌ها")
async def list_models(message: types.Message):

    models = get_all_approved_models()

    if not models:
        return await message.answer("❌ هیچ مدلی ثبت نشده")

    for model in models:
        name = model["name"]
        city = model["city"]
        activity = model["activity"]

        text = f"👤 {name}\n📍 {city}\n🎯 {activity}"

        kb = InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(
                text="👁 مشاهده پروفایل",
                callback_data=f"view_model:{model['telegram_id']}"
            )
        ]])

        await message.answer(text, reply_markup=kb)


# ================= مشاهده پروفایل مدل =================

@router.callback_query(F.data.startswith("view_model:"))
async def view_model(call: types.CallbackQuery):
    model_id = call.data.split(":")[1]

    model = get_model_by_id(model_id)

    if not model:
        return await call.answer("❌ مدل پیدا نشد", show_alert=True)

    kb = InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(
            text="📩 ارسال درخواست همکاری",
            callback_data=f"req:{model_id}"
        )
    ]])

    caption = (
        f"📄 پروفایل مدل:\n\n"
        f"👤 نام: {model['name']}\n"
        f"📍 شهر: {model['city']}\n"
        f"🎯 فعالیت: {model['activity']}\n"
        f"💰 آفیش: {model['price']:,} تومان\n"
        f"🎂 سن: {model['age']}"
    )

    await call.message.answer_photo(
        photo=model["photo"],
        caption=caption,
        reply_markup=kb
    )

    await call.answer()
