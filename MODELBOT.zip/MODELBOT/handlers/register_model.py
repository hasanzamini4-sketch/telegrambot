from database.db import set_user_role
from keyboards.role_menu import model_menu
from keyboards.register_keyboards import (
    province_keyboard,
    city_keyboard,
    activity_keyboard,
    hours_keyboard,
    price_keyboard,
    ACTIVITIES,
    PROVINCES
)

from aiogram import Router, types, F
from aiogram.fsm.context import FSMContext
from aiogram.filters import StateFilter
from aiogram.types import (
    ReplyKeyboardRemove,
    InlineKeyboardMarkup,
    InlineKeyboardButton
)

from states.register import RegisterModel
from config import ADMIN_ID
from database.db import create_model, approve_model, get_model

router = Router()


# ================= شروع ثبت نام =================

@router.message(F.text.contains("ثبت نام مدل"))
async def start_model_register(message: types.Message, state: FSMContext):
    existing = get_model(message.from_user.id)
    if existing:
        return await message.answer("✅ قبلاً ثبت‌نام کرده‌ای")

    await state.clear()
    await state.set_state(RegisterModel.name)
    await message.answer("👤 اسم و نام خانوادگی:", reply_markup=ReplyKeyboardRemove())


# ================= مراحل فرم =================

@router.message(StateFilter(RegisterModel.name))
async def process_name(message: types.Message, state: FSMContext):
    await state.update_data(name=message.text.strip())
    await state.set_state(RegisterModel.age)
    await message.answer("🎂 سن:")


@router.message(StateFilter(RegisterModel.age))
async def process_age(message: types.Message, state: FSMContext):
    if not message.text.isdigit():
        return await message.answer("❗ فقط عدد وارد کن")

    await state.update_data(age=int(message.text))
    await state.set_state(RegisterModel.height)
    await message.answer("📏 قد (سانتی‌متر):")


@router.message(StateFilter(RegisterModel.height))
async def process_height(message: types.Message, state: FSMContext):
    if not message.text.isdigit():
        return await message.answer("❗ فقط عدد")

    await state.update_data(height=int(message.text))
    await state.set_state(RegisterModel.weight)
    await message.answer("⚖️ وزن (کیلوگرم):")


@router.message(StateFilter(RegisterModel.weight))
async def process_weight(message: types.Message, state: FSMContext):
    if not message.text.isdigit():
        return await message.answer("❗ فقط عدد")

    await state.update_data(weight=int(message.text))
    await state.set_state(RegisterModel.province)

    await message.answer(
        "🏙 استان را انتخاب کن:",
        reply_markup=province_keyboard()
    )


# ================= استان =================

@router.message(StateFilter(RegisterModel.province))
async def process_province(message: types.Message, state: FSMContext):
    if message.text not in PROVINCES:
        return await message.answer("❗ لطفاً از لیست انتخاب کن")

    await state.update_data(province=message.text)
    await state.set_state(RegisterModel.city)

    await message.answer(
        "📍 شهر را انتخاب کن:",
        reply_markup=city_keyboard(message.text)
    )


# ================= شهر =================

@router.message(StateFilter(RegisterModel.city))
async def process_city(message: types.Message, state: FSMContext):
    data = await state.get_data()
    province = data.get("province")

    if message.text not in PROVINCES.get(province, []):
        return await message.answer("❗ لطفاً از لیست شهرها انتخاب کن")

    await state.update_data(city=message.text)
    await state.update_data(activities=[])

    await state.set_state(RegisterModel.activity)

    await message.answer(
        "🎭 می‌توانی چند فعالیت انتخاب کنی:",
        reply_markup=activity_keyboard([])
    )


# ================= فعالیت چند انتخابی =================

@router.message(StateFilter(RegisterModel.activity))
async def process_activity(message: types.Message, state: FSMContext):
    text = message.text.replace("✅ ", "")

    data = await state.get_data()
    selected = data.get("activities", [])

    if text == "پایان انتخاب":
        if not selected:
            return await message.answer("حداقل یک فعالیت انتخاب کن")

        await state.update_data(activity=" , ".join(selected))
        await state.set_state(RegisterModel.price)

        return await message.answer(
            "💰 مبلغ آفیش را انتخاب کن:",
            reply_markup=price_keyboard()
        )

    if text not in ACTIVITIES:
        return await message.answer("❗ لطفاً از دکمه‌ها استفاده کن")

    if text in selected:
        selected.remove(text)
    else:
        selected.append(text)

    await state.update_data(activities=selected)

    await message.answer(
        "🎭 می‌توانی چند فعالیت انتخاب کنی:",
        reply_markup=activity_keyboard(selected)
    )


# ================= قیمت =================

@router.message(StateFilter(RegisterModel.price))
async def process_price(message: types.Message, state: FSMContext):

    if message.text == "رایگان":
        await state.update_data(price=0)
    else:
        clean = message.text.replace(",", "")
        if not clean.isdigit():
            return await message.answer("❗ از دکمه‌ها انتخاب کن")

        await state.update_data(price=int(clean))

    await state.set_state(RegisterModel.hours)

    await message.answer(
        "⏰ ساعت همکاری را انتخاب کن:",
        reply_markup=hours_keyboard()
    )


# ================= ساعت =================

@router.message(StateFilter(RegisterModel.hours))
async def process_hours(message: types.Message, state: FSMContext):
    await state.update_data(hours=message.text)
    await state.set_state(RegisterModel.instagram)

    await message.answer(
        "📸 آیدی اینستاگرام (اختیاری - اگر نداری بنویس: ندارد)",
        reply_markup=ReplyKeyboardRemove()
    )


# ================= اینستاگرام =================

@router.message(StateFilter(RegisterModel.instagram))
async def process_instagram(message: types.Message, state: FSMContext):
    text = message.text.strip()
    if text.lower() == "ندارد":
        text = None

    await state.update_data(instagram=text)
    await state.set_state(RegisterModel.photo)

    await message.answer("🖼 عکس پروفایل را ارسال کن")


# ================= ذخیره =================

@router.message(StateFilter(RegisterModel.photo), F.photo)
async def process_photo(message: types.Message, state: FSMContext):
    data = await state.get_data()

    model_data = {
        "telegram_id": message.from_user.id,
        "name": data["name"],
        "age": data["age"],
        "height": data["height"],
        "weight": data["weight"],
        "province": data["province"],
        "city": data["city"],
        "activity": data["activity"],
        "hours": data["hours"],
        "price": data["price"],
        "instagram": data.get("instagram"),
        "photo": message.photo[-1].file_id
    }

    create_model(model_data)

    kb = InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(
            text="✅ تأیید",
            callback_data=f"model_ok:{message.from_user.id}"
        )
    ]])

    await message.bot.send_photo(
        ADMIN_ID,
        message.photo[-1].file_id,
        caption=f"مدل جدید:\n{data['name']}\nاستان: {data['province']}\nشهر: {data['city']}",
        reply_markup=kb
    )

    await message.answer("✅ برای بررسی ارسال شد")
    await state.clear()


@router.message(StateFilter(RegisterModel.photo))
async def photo_required(message: types.Message):
    await message.answer("❗ لطفاً فقط عکس ارسال کن")


# ================= تأیید ادمین =================

@router.callback_query(F.data.startswith("model_ok:"))
async def approve_model_handler(call: types.CallbackQuery):
    user_id = int(call.data.split(":")[1])

    approve_model(user_id)
    set_user_role(user_id, "model")

    await call.bot.send_message(
        user_id,
        "🎉 ثبت‌نام شما تأیید شد",
        reply_markup=model_menu()
    )

    await call.answer()
    await call.message.edit_reply_markup()
