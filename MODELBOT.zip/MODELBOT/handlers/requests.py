import datetime
from aiogram import Router, types, F
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from database.db import get_connection

router = Router()
REQUEST_LIMIT = 5


def today():
    return datetime.date.today().isoformat()


# ================= ارسال درخواست مستقیم =================

@router.callback_query(F.data.startswith("req:"))
async def send_request(call: types.CallbackQuery):
    employer_id = call.from_user.id
    model_id = int(call.data.split(":")[1])

    conn = get_connection()
    cur = conn.cursor()

    # سقف روزانه
    cur.execute("""
        SELECT COUNT(*) FROM direct_requests
        WHERE employer_id = ? AND created_at = ?
    """, (employer_id, today()))
    count = cur.fetchone()[0]

    if count >= REQUEST_LIMIT:
        await call.answer("❌ سقف ۵ درخواست امروز پر شده", show_alert=True)
        conn.close()
        return

    # بررسی تکراری
    cur.execute("""
        SELECT id FROM direct_requests
        WHERE employer_id = ? AND model_id = ?
        AND status = 'pending'
    """, (employer_id, model_id))

    if cur.fetchone():
        await call.answer("❌ قبلاً درخواست داده‌ای", show_alert=True)
        conn.close()
        return

    # ثبت درخواست
    cur.execute("""
        INSERT INTO direct_requests (employer_id, model_id, status, created_at)
        VALUES (?, ?, 'pending', ?)
    """, (employer_id, model_id, today()))

    conn.commit()
    conn.close()

    kb = InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="✅ قبول", callback_data=f"acc:{employer_id}"),
        InlineKeyboardButton(text="❌ رد", callback_data=f"rej:{employer_id}")
    ]])

    await call.bot.send_message(
        model_id,
        "📩 یک درخواست همکاری جدید داری 👇",
        reply_markup=kb
    )

    await call.answer("✅ درخواست ارسال شد", show_alert=True)


# ================= قبول درخواست =================

@router.callback_query(F.data.startswith("acc:"))
async def accept_request(call: types.CallbackQuery):
    employer_id = int(call.data.split(":")[1])
    model_id = call.from_user.id

    conn = get_connection()
    cur = conn.cursor()

    # تغییر وضعیت
    cur.execute("""
        UPDATE direct_requests
        SET status = 'accepted'
        WHERE employer_id = ? AND model_id = ?
        AND status = 'pending'
    """, (employer_id, model_id))

    # ایجاد چت
    cur.execute("""
        INSERT INTO chats (employer_id, model_id, active)
        VALUES (?, ?, 1)
    """, (employer_id, model_id))

    conn.commit()
    conn.close()

    await call.bot.send_message(
        employer_id,
        "🎉 درخواست همکاری شما پذیرفته شد\n"
        "💬 چت فعال شد"
    )

    await call.bot.send_message(
        model_id,
        "✅ درخواست را پذیرفتی\n"
        "💬 چت فعال شد"
    )

    await call.message.edit_reply_markup()
    await call.answer("چت فعال شد")


# ================= رد درخواست =================

@router.callback_query(F.data.startswith("rej:"))
async def reject_request(call: types.CallbackQuery):
    employer_id = int(call.data.split(":")[1])
    model_id = call.from_user.id

    conn = get_connection()
    cur = conn.cursor()

    cur.execute("""
        UPDATE direct_requests
        SET status = 'rejected'
        WHERE employer_id = ? AND model_id = ?
        AND status = 'pending'
    """, (employer_id, model_id))

    conn.commit()
    conn.close()

    await call.bot.send_message(
        employer_id,
        "❌ درخواست همکاری شما رد شد"
    )

    await call.message.edit_reply_markup()
    await call.answer("رد شد")
