import json, os
from aiogram import Router, types, F
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import StatesGroup, State
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

router = Router()
OFFERS_PATH = "data/offers.json"


class OfferState(StatesGroup):
    text = State()


def load_offers():
    os.makedirs("data", exist_ok=True)
    if not os.path.exists(OFFERS_PATH):
        with open(OFFERS_PATH, "w", encoding="utf-8") as f:
            json.dump([], f)
    with open(OFFERS_PATH, encoding="utf-8") as f:
        return json.load(f)


def save_offers(data):
    with open(OFFERS_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


@router.callback_query(F.data.startswith("offer_"))
async def start_offer(call: types.CallbackQuery, state: FSMContext):
    project_id = int(call.data.split("_")[1])
    await state.update_data(project_id=project_id)
    await state.set_state(OfferState.text)
    await call.message.answer("✍️ متن پیشنهاد همکاری را بنویس:")
    await call.answer()


@router.message(OfferState.text)
async def save_offer(message: types.Message, state: FSMContext):
    data = await state.get_data()
    offers = load_offers()

    offers.append({
        "project_id": data["project_id"],
        "model_id": message.from_user.id,
        "text": message.text
    })

    save_offers(offers)
    await state.clear()

    await message.answer(
        "✅ پیشنهاد شما ارسال شد",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="📋 بازگشت به پروژه‌ها", callback_data="list_projects")]
        ])
    )
