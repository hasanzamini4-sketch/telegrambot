from aiogram import Router, types, F
from aiogram.fsm.context import FSMContext
from aiogram.filters import StateFilter
from aiogram.types import ReplyKeyboardRemove

from states.register import SearchModel
from keyboards.register_keyboards import (
    province_keyboard,
    city_keyboard,
    ACTIVITIES,
    activity_keyboard,
    price_keyboard,
    PROVINCES
)

from database.db import search_models

router = Router()


# شروع جستجو
@router.message(F.text == "🔍 جستجوی مدل")
async def start_search(message: types.Message, state: FSMContext):
    await state.clear()
    await state.set_state(SearchModel.province)

    await message.answer(
        "🏙 استان را انتخاب کن:",
        reply_markup=province_keyboard()
    )


# استان
@router.message(StateFilter(SearchModel.province))
async def search_province(message: types.Message, state: FSMContext):
    if message.text not in PROVINCES:
        return await message.answer("❗ از لیست انتخاب کن")

    await state.update_data(province=message.text)
    await state.set_state(SearchModel.city)

    await message.answer(
        "📍 شهر را انتخاب کن:",
        reply_markup=city_keyboard(message.text)
    )


# شهر
@router.message(StateFilter(SearchModel.city))
async def search_city(message: types.Message, state: FSMContext):
    await state.update_data(city=message.text)
    await state.set_state(SearchModel.activity)

    await message.answer(
        "🎭 فعالیت را انتخاب کن:",
        reply_markup=activity_keyboard([])
    )


# فعالیت (تک انتخابی در سرچ)
@router.message(StateFilter(SearchModel.activity))
async def search_activity(message: types.Message, state: FSMContext):
    text = message.text.replace("✅ ", "")

    if text not in ACTIVITIES:
        return await message.answer("❗ از لیست انتخاب کن")

    await state.update_data(activity=text)
    await state.set_state(SearchModel.max_price)

    await message.answer(
        "💰 حداکثر مبلغ را انتخاب کن:",
        reply_markup=price_keyboard()
    )


# حداکثر مبلغ
@router.message(StateFilter(SearchModel.max_price))
async def search_price(message: types.Message, state: FSMContext):

    if message.text == "رایگان":
        max_price = 0
    else:
        clean = message.text.replace(",", "")
        if not clean.isdigit():
            return await message.answer("❗ از دکمه‌ها انتخاب کن")
        max_price = int(clean)

    await state.update_data(max_price=max_price)
    await state.set_state(SearchModel.min_age)

    await message.answer("حداقل سن؟", reply_markup=ReplyKeyboardRemove())


# حداقل سن
@router.message(StateFilter(SearchModel.min_age))
async def search_min_age(message: types.Message, state: FSMContext):
    if not message.text.isdigit():
        return await message.answer("عدد وارد کن")

    await state.update_data(min_age=int(message.text))
    await state.set_state(SearchModel.max_age)

    await message.answer("حداکثر سن؟")


# حداکثر سن + اجرای جستجو
@router.message(StateFilter(SearchModel.max_age))
async def search_max_age(message: types.Message, state: FSMContext):
    if not message.text.isdigit():
        return await message.answer("عدد وارد کن")

    await state.update_data(max_age=int(message.text))

    filters = await state.get_data()
    results = search_models(filters)

    if not results:
        await message.answer("❌ نتیجه‌ای یافت نشد")
        await state.clear()
        return

    for model in results:
        caption = (
            f"👤 {model['name']}\n"
            f"سن: {model['age']}\n"
            f"شهر: {model['city']}\n"
            f"فعالیت: {model['activity']}\n"
            f"مبلغ: {model['price']:,}"
        )

        await message.answer_photo(model["photo"], caption=caption)

    await state.clear()
