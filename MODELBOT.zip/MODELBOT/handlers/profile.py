from aiogram import Router, types, F
from database.db import (
    get_user_role,
    get_model,
    get_employer
)

router = Router()


@router.message(F.text == "👤 پروفایل من")
async def show_profile(message: types.Message):
    telegram_id = message.from_user.id

    role = get_user_role(telegram_id)

    if not role:
        return await message.answer("❌ شما هنوز ثبت‌نام نکرده‌اید.")

    # ================= MODEL =================
    if role == "model":
        model = get_model(telegram_id)

        if not model:
            return await message.answer("❌ پروفایل مدل یافت نشد.")

        if model["approved"] == 0:
            return await message.answer("⏳ پروفایل شما هنوز تأیید نشده.")

        caption = (
            f"👤 نام: {model['name']}\n"
            f"🎂 سن: {model['age']}\n"
            f"📏 قد: {model['height']}\n"
            f"⚖ وزن: {model['weight']}\n"
            f"🏙 شهر: {model['city']}\n"
            f"🎭 فعالیت: {model['activity']}\n"
            f"⏰ ساعات همکاری: {model['hours']}\n"
            f"💰 آفیش: {model['price']}"
        )

        return await message.answer_photo(
            model["photo"],
            caption=caption
        )

    # ================= EMPLOYER =================
    if role == "employer":
        employer = get_employer(telegram_id)

        if not employer:
            return await message.answer("❌ پروفایل کارفرما یافت نشد.")

        if employer["approved"] == 0:
            return await message.answer("⏳ پروفایل شما هنوز تأیید نشده.")

        text = (
            f"🏢 نام: {employer['name']}\n"
            f"🏙 شهر: {employer['city']}\n"
            f"📞 تلفن: {employer['phone']}\n"
            f"📝 توضیحات:\n{employer['description']}"
        )

        return await message.answer(text)
