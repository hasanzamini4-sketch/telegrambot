from aiogram import BaseMiddleware
from database.db import get_user_role


class RoleMiddleware(BaseMiddleware):
    def __init__(self, allowed_role: str):
        self.allowed_role = allowed_role

    async def __call__(self, handler, event, data):
        user = event.from_user
        role = get_user_role(user.id)

        if role != self.allowed_role:
            await event.answer("⛔ دسترسی غیرمجاز")
            return

        return await handler(event, data)
