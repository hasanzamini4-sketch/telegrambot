from aiogram.fsm.state import StatesGroup, State


# ================= ثبت نام مدل =================

class RegisterModel(StatesGroup):
    name = State()
    age = State()
    height = State()
    weight = State()
    province = State()
    city = State()
    activity = State()
    price = State()
    hours = State()
    instagram = State()
    photo = State()


# ================= ثبت نام کارفرما =================

class RegisterEmployer(StatesGroup):
    name = State()
    city = State()
    phone = State()
    description = State()
    instagram = State()   # ✅ اضافه شد
    photo = State()

class SearchModel(StatesGroup):
    province = State()
    city = State()
    activity = State()
    max_price = State()
    min_age = State()
    max_age = State()

from aiogram.fsm.state import State, StatesGroup


class CreateProject(StatesGroup):
    title = State()
    description = State()
    budget = State()
