from aiogram.fsm.state import StatesGroup, State

class EditProfile(StatesGroup):
    photo = State()
    name = State()
    age = State()
    height = State()
    weight = State()
    province = State()
    city = State()
    activity = State()
    days = State()
    hours = State()
    price = State()
