import json
import os

def is_model(user_id: str) -> bool:
    if not os.path.exists("data/models.json"):
        return False
    with open("data/models.json", encoding="utf-8") as f:
        return user_id in json.load(f)

def is_employer(user_id: str) -> bool:
    if not os.path.exists("data/employers.json"):
        return False
    with open("data/employers.json", encoding="utf-8") as f:
        return user_id in json.load(f)
